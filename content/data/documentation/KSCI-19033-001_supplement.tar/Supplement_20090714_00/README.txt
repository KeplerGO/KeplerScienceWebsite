Kepler Instrument Handbook Supplement
File List

1.  morc_2_ra_dec_4_seasons.xls -- Excel spreadsheet showing Module Output Row Column (MORC)
    to RA and DEC conversion for center and corners of each channel
    
    morc_2_ra_dec_4_seasons.txt -- MORC to RA-DEC in text format

2.  prf_ch_01-prf_ch_84.fits  -- PRFs in a 15x15x84 FITS cube.  The images are ordered 1-84 in the cube.

3.  spectral_response.xls


